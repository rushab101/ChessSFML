# RPG

RPG is a simple, educational project aiming to create an interesting 2D role-playing game using SFML library along with C++ programming language.
