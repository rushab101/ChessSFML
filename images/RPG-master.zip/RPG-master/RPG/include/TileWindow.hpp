#pragma once

#include <SFML/Graphics/Drawable.hpp>
#include <SFML/Graphics/RenderTarget.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <SFML/Graphics/Transformable.hpp>
#include <SFML/Window/Event.hpp>

#include <iostream>

class TileWindow : public sf::Drawable, public sf::Transformable
{
public:
	static constexpr float Width = 320.f;
	static constexpr float Height = 960.f;
	static constexpr float TilesetWidth = Width - 64.f;
	static constexpr float TilesetHeight = Height - 64.f;
	static const sf::Vector2f Offset;

public:
	TileWindow(const sf::Window& window, const sf::Texture& windowTexture, const sf::Texture& tilesetTexture, const sf::Texture& markerTexture);

	virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const override;
	void handleInput(const sf::Event& event);

	void moveMarkerRect(int x, int y);
	sf::IntRect getMarkerRect() const;

	const sf::Texture* getTilesetTexture() const;

private:
	const sf::Window& Window;
	sf::Sprite m_window;
	sf::Sprite m_tileset;
	sf::Sprite m_tileMarker;
	int m_verticalTileCount;
	int m_verticalScroll;
};
