#pragma once

#include "Actor.hpp"

class Enemy : public Actor
{
public:
	Enemy(const sf::Texture& texture, const sf::Vector2f& baseVelocity);
	virtual void update(sf::Time dt) override;

	void setPlayerPosition(sf::Vector2f position);

private:
	sf::Vector2f m_playerPosition;
	bool m_chase;
};
