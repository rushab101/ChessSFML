#pragma once

#include <map>
#include <SFML/Graphics/Texture.hpp>

enum TextureFlags : unsigned int
{
	None		= 0,
	Smooth		= 1,
	Repeated	= 2,
};

struct TextureInfo
{
	std::string filename;
	unsigned int flags;
};

class TextureHolder
{
public:
	TextureHolder();
	bool loadTexture(const std::string& key, TextureInfo textureInfo);
	bool loadAll();

	sf::Texture* get(const std::string& key);
	const sf::Texture* get(const std::string& key) const;

private:
	std::map<std::string, sf::Texture> m_data;
};

