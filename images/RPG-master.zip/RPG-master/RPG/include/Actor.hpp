#pragma once

#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <SFML/Graphics/RenderTarget.hpp>
#include <SFML/Window/Event.hpp>

enum class Direction
{
	Down,
	Left,
	Right,
	Up,
	Count
};

class Actor
{
public:
	Actor(const sf::Texture& texture, const sf::Vector2f& baseVelocity);
	void move(Direction direction, sf::Time dt);
	virtual void update(sf::Time dt) = 0;
	void setFrame(Direction direction, int frameNumber);
	void draw(sf::RenderTarget& target) const;

	sf::Sprite& getSprite();
	Direction getDirection() const;

private:
	sf::Sprite m_sprite;
	Direction m_direction;
	int m_actualFrame;
	sf::Time m_frameTimer;

protected:
	const sf::Vector2f BaseVelocity;
	const sf::Vector2i SizeOfFrame;
	const int MaximumFrame;
	const sf::Time TimePerFrame;
};