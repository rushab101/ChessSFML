#pragma once

#include <SFML/Graphics/Drawable.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <SFML/Graphics/Transformable.hpp>
#include <SFML/Graphics/RenderTarget.hpp>
#include <SFML/Window/Event.hpp>
#include <functional>
#include <map>

class Button : public sf::Drawable, public sf::Transformable
{
public:
	Button(const sf::Window& window, const sf::Texture& texture);

	void handleInput(const sf::Event& event);
	virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const override;

	bool addCallback(const std::string& name, std::function<void(void)> callback);
	bool removeCallback(const std::string& name);

private:
	const sf::Window& m_window;
	sf::Sprite m_sprite;
	std::map <std::string, std::function<void(void)>> m_callbacks;

	bool m_hoverOver;
};
