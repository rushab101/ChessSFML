#pragma once

#include "Actor.hpp"

class Player : public Actor
{
public:
	Player(const sf::Texture& texture, const sf::Vector2f& baseVelocity);
	void handleRealTimeInput(sf::Time dt);
	virtual void update(sf::Time dt) override;
};