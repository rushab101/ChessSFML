#pragma once

#include <SFML/Graphics/Drawable.hpp>
#include <SFML/Graphics/Font.hpp>
#include <SFML/Graphics/RectangleShape.hpp>
#include <SFML/Graphics/RenderTarget.hpp>
#include <SFML/Graphics/Transformable.hpp>
#include <SFML/Graphics/Text.hpp>
#include <SFML/Window/Event.hpp>
#include <SFML/System/String.hpp>

#include <iostream>

enum ASCII : sf::Uint32
{
	Backspace = 8,
	Return = 13,
	Escape = 27,
};

class Console : public sf::Drawable, public sf::Transformable
{
public:
	Console(const sf::Font& font);
	void handleInput(const sf::Event& event);

	virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const override;

private:
	sf::Text m_text;
	sf::String m_string;
	sf::RectangleShape m_shape;
};
