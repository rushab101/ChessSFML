#include "..\include\Player.hpp"

Player::Player(const sf::Texture & texture, const sf::Vector2f& baseVelocity)
: Actor{texture, baseVelocity}
{
}

void Player::handleRealTimeInput(sf::Time dt)
{
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))
		move(Direction::Up, dt);
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))
		move(Direction::Right, dt);
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
		move(Direction::Left, dt);
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::S))
		move(Direction::Down, dt);
	else
		setFrame(getDirection(), 0);
}

void Player::update(sf::Time dt)
{
	handleRealTimeInput(dt);
}
