#include "..\include\Enemy.hpp"

Enemy::Enemy(const sf::Texture & texture, const sf::Vector2f& baseVelocity)
: Actor{ texture, baseVelocity }
, m_playerPosition{0.f, 0.f}
, m_chase{false}
{
}

void Enemy::update(sf::Time dt)
{
	if (m_chase)
	{
		sf::Sprite sprite = getSprite();
		sf::Vector2f myPosition = sprite.getPosition();

		bool moveHorizontally = abs(myPosition.x - m_playerPosition.x) > SizeOfFrame.x / 2.f;
		bool moveVertically = abs(myPosition.y - m_playerPosition.y) > SizeOfFrame.y / 2.f;

		if (!moveHorizontally && !moveVertically)
			m_chase = false;
		else
		{
			if (moveHorizontally)
			{
				if (myPosition.x < m_playerPosition.x)
					move(Direction::Right, dt);
				else if (myPosition.x > m_playerPosition.x)
					move(Direction::Left, dt);
				return;
			}

			if (moveVertically)
			{
				if (myPosition.y > m_playerPosition.y)
					move(Direction::Up, dt);
				else if (myPosition.y < m_playerPosition.y)
					move(Direction::Down, dt);
			}
		}		
	}
}

void Enemy::setPlayerPosition(sf::Vector2f position)
{
	m_playerPosition = position;
	m_chase = true;
}
