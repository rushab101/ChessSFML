#include "..\include\TextureHolder.hpp"

TextureHolder::TextureHolder()
: m_data{}
{
}

bool TextureHolder::loadTexture(const std::string& key, TextureInfo textureInfo)
{
	if (m_data.find(key) != m_data.end()) // duplicate key
		return false;
	else
	{
		m_data[key] = sf::Texture();
		auto& texture = m_data[key];

		if (!texture.loadFromFile(textureInfo.filename))
		{
			m_data.erase(m_data.find(key)); // clean
			return false;
		}

		if (textureInfo.flags & TextureFlags::Smooth)
			texture.setSmooth(true);

		if (textureInfo.flags & TextureFlags::Repeated)
			texture.setRepeated(true);

		return true;
	}
}

bool TextureHolder::loadAll()
{
	bool status = true;

	status &= loadTexture("Background.png", { "resources\\textures\\Background.png", TextureFlags::None });
	status &= loadTexture("Character.png", { "resources\\textures\\Character.png", TextureFlags::None });
	status &= loadTexture("Snake.png", { "resources\\textures\\Snake.png", TextureFlags::None });
	status &= loadTexture("Tileset.png", { "resources\\textures\\Tileset.png", TextureFlags::None });
	status &= loadTexture("LongTileset.png", { "resources\\textures\\LongTileset.png", TextureFlags::None });
	status &= loadTexture("TileWindow.png", { "resources\\textures\\TileWindow.png", TextureFlags::None });
	status &= loadTexture("TileMarker.png", { "resources\\textures\\TileMarker.png", TextureFlags::None });
	status &= loadTexture("Button.png", { "resources\\gui\\Button.png", TextureFlags::None });

	return status;
}

sf::Texture * TextureHolder::get(const std::string & key)
{
	auto it = m_data.find(key);

	if (it != m_data.end())
		return &it->second;
	else
		return nullptr;
}

const sf::Texture * TextureHolder::get(const std::string & key) const
{
	auto it = m_data.find(key);

	if (it != m_data.end())
		return &it->second;
	else
		return nullptr;
}
