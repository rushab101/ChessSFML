#include "..\include\Button.hpp"

Button::Button(const sf::Window & window, const sf::Texture & texture)
: m_window{window}
, m_sprite{texture}
, m_callbacks{}
, m_hoverOver{false}
{
}

void Button::handleInput(const sf::Event & event)
{
	switch (event.type)
	{
		case sf::Event::MouseButtonReleased:
		{
			if (getTransform().transformRect(m_sprite.getLocalBounds()).contains(static_cast<sf::Vector2f>(sf::Mouse::getPosition(m_window))))
			{
				for (auto& callback : m_callbacks)
				{
					callback.second();
				}
			}
		} break;

		case sf::Event::MouseMoved:
		{
			
			if ((getTransform().transformRect(m_sprite.getLocalBounds()).contains(float(event.mouseMove.x), float(event.mouseMove.y))))
			{
				m_sprite.setColor(sf::Color(200, 200, 200, 255));
				m_hoverOver = true;
			}
			else
			{
				m_sprite.setColor(sf::Color::White);
				m_hoverOver = false;
			}
		}
	}
}

void Button::draw(sf::RenderTarget & target, sf::RenderStates states) const
{
	states.transform *= getTransform();

	target.draw(m_sprite, states);
}

bool Button::addCallback(const std::string & name, std::function<void(void)> callback)
{
	if (m_callbacks.count(name) != 0) return false;
	
	m_callbacks[name] = callback;
	return true;
}

bool Button::removeCallback(const std::string & name)
{
	if (m_callbacks.count(name) == 0) return false;

	m_callbacks.erase(name);
	return true;
}
