#include "..\include\Actor.hpp"

Actor::Actor(const sf::Texture & texture, const sf::Vector2f& baseVelocity)
: m_sprite{ texture, sf::IntRect{ 0, 0, int(texture.getSize().x / 4), int(texture.getSize().y / 4) } }
, m_direction{ Direction::Down }
, m_actualFrame{ 0 }
, m_frameTimer{ sf::Time::Zero }
, BaseVelocity{ baseVelocity }
, SizeOfFrame{ texture.getSize().x / 4, texture.getSize().y / 4 }
, MaximumFrame{ 4 }
, TimePerFrame{ sf::seconds(0.2f) }
{
	m_sprite.setOrigin(SizeOfFrame.x / 2.f, SizeOfFrame.y / 2.f);
}

void Actor::move(Direction direction, sf::Time dt)
{
	switch (direction)
	{
		case Direction::Down:
		{
			if (m_direction != Direction::Down)
			{
				setFrame(Direction::Down, 0);
			}

			m_frameTimer += dt;
			if (m_frameTimer >= TimePerFrame)
			{
				m_frameTimer -= TimePerFrame;
				setFrame(Direction::Down, m_actualFrame + 1);
			}
			m_sprite.move(0.f, BaseVelocity.y);
		}
		break;

		case Direction::Left:
		{
			if (m_direction != Direction::Left)
			{
				setFrame(Direction::Left, 0);
			}

			m_frameTimer += dt;
			if (m_frameTimer >= TimePerFrame)
			{
				m_frameTimer -= TimePerFrame;
				setFrame(Direction::Left, m_actualFrame + 1);
			}
			m_sprite.move(-BaseVelocity.x, 0.f);
		}
		break;

		case Direction::Right:
		{
			if (m_direction != Direction::Right)
			{
				setFrame(Direction::Right, 0);
			}

			m_frameTimer += dt;
			if (m_frameTimer >= TimePerFrame)
			{
				m_frameTimer -= TimePerFrame;
				setFrame(Direction::Right, m_actualFrame + 1);
			}
			m_sprite.move(BaseVelocity.x, 0.f);
		}
		break;

		case Direction::Up:
		{
			if (m_direction != Direction::Up)
			{
				setFrame(Direction::Up, 0);
			}

			m_frameTimer += dt;
			if (m_frameTimer >= TimePerFrame)
			{
				m_frameTimer -= TimePerFrame;
				setFrame(Direction::Up, m_actualFrame + 1);
			}
			m_sprite.move(0.f, -BaseVelocity.y);
		}
		break;

		default:
			break;
	}
}

void Actor::setFrame(Direction newDirection, int frameNumber)
{
	m_direction = newDirection;
	m_actualFrame = frameNumber % MaximumFrame;
	m_sprite.setTextureRect(sf::IntRect{ m_actualFrame * SizeOfFrame.x, (int)m_direction * SizeOfFrame.y, SizeOfFrame.x, SizeOfFrame.y });
}

void Actor::draw(sf::RenderTarget & target) const
{
	target.draw(m_sprite);
}

sf::Sprite & Actor::getSprite()
{
	return m_sprite;
}

Direction Actor::getDirection() const
{
	return m_direction;
}