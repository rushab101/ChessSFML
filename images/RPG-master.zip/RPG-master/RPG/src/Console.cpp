#include "..\include\Console.hpp"

Console::Console(const sf::Font & font)
: m_text{" ~$ ", font, 20}
, m_string{}
, m_shape{ {320.f, 240.f} }
{
	m_shape.setFillColor(sf::Color(48, 10, 30, 200));
}

void Console::handleInput(const sf::Event & event)
{
	bool needUpdate = false;

	switch (event.type)
	{
		case sf::Event::KeyPressed:
		{
			if (event.key.code == sf::Keyboard::Return)
			{
				m_string.clear();
				needUpdate = true;
			}
			else if (event.key.code == sf::Keyboard::BackSpace)
			{
				if (m_string.getSize() > 0)
				{
					m_string.erase(m_string.getSize() - 1, 1);
					needUpdate = true;
				}
			}
		} 
		break;
			
		case sf::Event::TextEntered:
		{
			//std::cout << event.text.unicode << ' '; // <- debug

			if (event.text.unicode < 128)
			{
				switch (event.text.unicode)
				{
					case ASCII::Backspace:
						if (!m_string.isEmpty()) m_string.erase(m_string.getSize() - 1, 1);
						break;
					case ASCII::Return:
						m_string.clear();
						break;
					case ASCII::Escape:
						std::cout << "Escape\n";
						break;
					default:
						m_string += event.text.unicode;
						break;
				}

				needUpdate = true;
			}
		} 
		break;
	}

	if (needUpdate)
	{
		m_text.setString(" ~$ " + m_string);
	}
}

void Console::draw(sf::RenderTarget & target, sf::RenderStates states) const
{
	states.transform *= getTransform();

	target.draw(m_shape, states);
	target.draw(m_text, states);
}
