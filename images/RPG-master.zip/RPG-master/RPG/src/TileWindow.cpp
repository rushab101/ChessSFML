#include "..\include\TileWindow.hpp"

const sf::Vector2f TileWindow::Offset = sf::Vector2f(32.f, 32.f);

TileWindow::TileWindow(const sf::Window & window, const sf::Texture & windowTexture, const sf::Texture & tilesetTexture, const sf::Texture & markerTexture)
: Window{ window }
, m_window{ windowTexture }
, m_tileset{ tilesetTexture }
, m_tileMarker{ markerTexture }
, m_verticalTileCount{ (int)tilesetTexture.getSize().y / 32}
, m_verticalScroll{ 0 }
{
	m_tileset.move(Offset);
	m_tileMarker.move(Offset);

	m_tileset.setTextureRect(sf::IntRect(0, 0, int(TilesetWidth), int(TilesetHeight)));
}

void TileWindow::draw(sf::RenderTarget & target, sf::RenderStates states) const
{
	states.transform *= getTransform();
	target.draw(m_window, states);
	target.draw(m_tileset, states);
	target.draw(m_tileMarker, states);
}

void TileWindow::handleInput(const sf::Event & event)
{
	switch (event.type)
	{
		case sf::Event::MouseButtonPressed:
		{
			// screen coordinates, (0,0) means upper-left corner of screen
			auto mousePos = static_cast<sf::Vector2f>(sf::Mouse::getPosition(Window));

			// transform to TileWindow coordinates, now (0,0) means upper-left corner of window
			mousePos = getInverseTransform().transformPoint(mousePos);

			// transform to tileset coordinates, now (0,0) means upper-left corner of tileset
			mousePos -= Offset;

			// check whether mousePos is inside tileset
			if (mousePos.x >= 0.f && mousePos.x <= TilesetWidth - 1.f)
			{
				if (mousePos.y >= 0.f && mousePos.y <= std::min(TilesetHeight - 1.f, 32.f * m_verticalTileCount - 1.f))
				{
					// we use coordinates relative to tileset, but marker is placed relative to window, we must
					// add offset to adjust that
					sf::Vector2i tilePos{ static_cast<int>(mousePos.x) / 32, static_cast<int>(mousePos.y) / 32 };
					sf::Vector2f markerPos = sf::Vector2f(tilePos.x * 32.f, tilePos.y * 32.f) + Offset;
					m_tileMarker.setPosition(markerPos);
				}
			}

		} break;

		case sf::Event::MouseWheelScrolled:
		{
			// mousePos will be in TileWindow coordinates, (0,0) will mean upper-left corner of screen
			auto mousePos = sf::Vector2f(float(event.mouseWheelScroll.x), float(event.mouseWheelScroll.y));
			mousePos = getInverseTransform().transformPoint(mousePos);

			// check whether mouse is inside TileWindow
			if (mousePos.x >= 0.f && mousePos.x <= Width - 1.f)
			{
				if (mousePos.y >= 0.f && mousePos.y <= Height - 1)
				{
					if (event.mouseWheelScroll.wheel == sf::Mouse::VerticalWheel)
					{
						// delta direction is flipped in comparison to SFML coordinates
						int delta = static_cast<int>(-event.mouseWheelScroll.delta);

						if ((delta < 0 && m_verticalScroll > 0) || (delta > 0 && m_verticalScroll < m_verticalTileCount - int(TilesetHeight) / 32))
						{
							m_verticalScroll += delta;

							// move tileset vertically to adjust for scroll
							auto rect = m_tileset.getTextureRect();
							rect.top += 32 * delta;
							m_tileset.setTextureRect(rect);
						}
					}

				}
			}

		} break;
	}
}

void TileWindow::moveMarkerRect(int x, int y)
{
	auto oldPos = m_tileMarker.getPosition();

	// transform position to tileset coordinate system
	int newX = int(oldPos.x - Offset.x) + 32 * x;
	while (newX < 0) newX += int(TilesetWidth);
	newX %= int(TilesetWidth);

	// transform position to tileset coordinate system
	int newY = int(oldPos.y - Offset.y) + 32 * y;
	while (newY < 0) newY += int(std::min(TilesetHeight, 32.f * m_verticalTileCount));
	newY %= int(std::min(TilesetHeight, 32.f * m_verticalTileCount));

	// transform position back to TileWindow coordinate system
	m_tileMarker.setPosition(float(newX) + Offset.x, float(newY) + Offset.y);
}

sf::IntRect TileWindow::getMarkerRect() const
{
	// markerPos is placed in TileWindow coordinate system, but we
	// need coordinates relative to tileset
	auto markerPos = sf::Vector2i(m_tileMarker.getPosition() - Offset);

	// adjust for scroll
	markerPos.y += m_verticalScroll * 32;

	return sf::IntRect(markerPos.x, markerPos.y, 32, 32);
}

const sf::Texture * TileWindow::getTilesetTexture() const
{
	return m_tileset.getTexture();
}
