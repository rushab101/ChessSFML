#include <SFML/Graphics.hpp>
#include <iostream>

#include "../include/Button.hpp"
#include "../include/TileWindow.hpp"
#include "../include/TextureHolder.hpp"

#include <experimental/vector>
#include <vector>

enum TilePlacement
{
	Continuous = 0,
	Discrete = 1,
};

int main()
{
	TextureHolder textures;
	if (!textures.loadAll())
	{
		std::cout << "textures::loadAll() failed!\n";
		return EXIT_FAILURE;
	}

	sf::Font courierNew;
	if (!courierNew.loadFromFile("resources\\fonts\\cour.ttf"))
	{
		std::cout << "courierNew::loadFromFile() failed!\n";
		return EXIT_FAILURE;
	}

	sf::RenderWindow window(sf::VideoMode(1280, 960), "RPG");

	const sf::Time TimePerFrame = sf::seconds(1.f / 60.f);
	sf::Time elapsed = sf::Time::Zero;
	sf::Clock clock;

	sf::RenderTexture renderTexture;
	if (!renderTexture.create(800, 600))
	{
		std::cout << "renderTexture::create() failed!\n";
		return EXIT_FAILURE;
	}

	std::vector<sf::Sprite> tiles;
	TilePlacement tilePlacement = TilePlacement::Discrete;

	TileWindow tileWindow{ window, *textures.get("TileWindow.png"), *textures.get("LongTileset.png"), *textures.get("TileMarker.png") };
	tileWindow.setPosition(960.f, 0.f);

	sf::View cameraView{ { 640.f, 480.f }, {1280.f, 960.f} };
	sf::Vector2f cameraSpeed{ 320.f, 320.f };

	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			// debug functionality
			if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::F1)
			{
				auto rect = tileWindow.getMarkerRect();
				std::cout << "tileWindow::getMarkerRect() returned: {" << rect.left << ',' << rect.top << ',' << rect.width << ',' << rect.height << "}\n";
			}
			else if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::F2)
			{
				sf::Vector2i mouseScreenPosition = sf::Mouse::getPosition(window);
				sf::Vector2f mouseGamePosition = window.mapPixelToCoords(mouseScreenPosition, cameraView);

				std::cout << "mouseScreenPosition: {" << mouseScreenPosition.x << ',' << mouseScreenPosition.y << "}\n";
				std::cout << "mouseGamePosition: {" << mouseGamePosition.x << ',' << mouseGamePosition.y << "}\n";
			}


			if (event.type == sf::Event::Closed)
				window.close();
			else if (event.type == sf::Event::MouseButtonPressed && event.key.code == sf::Mouse::Middle)
			{
				if (tilePlacement == TilePlacement::Continuous) tilePlacement = TilePlacement::Discrete;
				else tilePlacement = TilePlacement::Continuous;
			}
			else if (event.type == sf::Event::KeyPressed)
			{
				switch (event.key.code)
				{
					case sf::Keyboard::W:
						tileWindow.moveMarkerRect(0, -1);
						break;
					case sf::Keyboard::S:
						tileWindow.moveMarkerRect(0, +1);
						break;
					case sf::Keyboard::A:
						tileWindow.moveMarkerRect(-1, 0);
						break;
					case sf::Keyboard::D:
						tileWindow.moveMarkerRect(+1, 0);
						break;
				}
			}
			tileWindow.handleInput(event);
		}

		elapsed += clock.restart();
		while (elapsed >= TimePerFrame)
		{
			// camera movement with arrow keys
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
				cameraView.move(0.f, -cameraSpeed.y * TimePerFrame.asSeconds());
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
				cameraView.move(0.f, +cameraSpeed.y * TimePerFrame.asSeconds());

			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
				cameraView.move(-cameraSpeed.x * TimePerFrame.asSeconds(), 0.f);
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
				cameraView.move(+cameraSpeed.x * TimePerFrame.asSeconds(), 0.f);

			// adding/erasing tiles to/from renderTexture
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
			{
				sf::Vector2i mouseScreenPosition = sf::Mouse::getPosition(window);
				sf::Vector2f mouseGamePosition = window.mapPixelToCoords(mouseScreenPosition, cameraView);

				// for now renderTexture is located at the start of game world
				if (mouseGamePosition.x >= 0.f && mouseGamePosition.x <= float(renderTexture.getSize().x) - 1.f)
				{
					if (mouseGamePosition.y >= 0.f && mouseGamePosition.y <= float(renderTexture.getSize().y) - 1.f)
					{
						if (tilePlacement == TilePlacement::Continuous)
						{
							tiles.push_back(sf::Sprite(*tileWindow.getTilesetTexture(), tileWindow.getMarkerRect()));
							tiles[tiles.size() - 1].setPosition(mouseGamePosition);
						}
						else
						{
							sf::Vector2f discretePosition{ 32.f * float(int(mouseGamePosition.x) / 32), 32.f * float(int(mouseGamePosition.y) / 32) };
							tiles.push_back(sf::Sprite(*tileWindow.getTilesetTexture(), tileWindow.getMarkerRect()));
							tiles[tiles.size() - 1].setPosition(discretePosition);
						}
						
					}
				}
			}
			else if (sf::Mouse::isButtonPressed(sf::Mouse::Right))
			{
				sf::Vector2i mouseScreenPosition = sf::Mouse::getPosition(window);
				sf::Vector2f mouseGamePosition = window.mapPixelToCoords(mouseScreenPosition, cameraView);
				std::experimental::erase_if(tiles, [&mouseGamePosition](const sf::Sprite& sprite) {
					auto d = sprite.getPosition() + sf::Vector2f(16.f, 16.f);
					return abs(d.x - mouseGamePosition.x) < 16.f && abs(d.y - mouseGamePosition.y) < 16.f;
				});
			}

			elapsed -= TimePerFrame;
		}

		window.clear();
			
		// draw stuff in game coordinates...
		window.setView(cameraView);

		// draw stuff to render texture...
		renderTexture.clear(sf::Color(0, 191, 255));
		for (auto& sprite : tiles) renderTexture.draw(sprite);
		renderTexture.display();

		window.draw(sf::Sprite(renderTexture.getTexture()));

		// draw stuff in screen coordinates...
		window.setView(window.getDefaultView());
		window.draw(tileWindow);

		window.display();
	}

	return 0;
}